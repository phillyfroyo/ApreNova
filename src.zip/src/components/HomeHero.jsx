export default function HomeHero() {
  return (
    <div style={{ padding: '4rem', textAlign: 'center', fontSize: '2rem' }}>
      ApreNova Hero Section
    </div>
  );
}
