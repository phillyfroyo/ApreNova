import HomeHero from '@/components/HomeHero';

export default function EnglishHomePage() {
  return <HomeHero language="en" />;
}
