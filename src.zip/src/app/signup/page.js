export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center text-2xl font-[Alice]">
      Welcome to the Sign Up Page 🚀
    </div>
  );
}
