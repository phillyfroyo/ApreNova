// src/app/layout.tsx
import './globals.css';
import SessionWrapper from '../components/SessionWrapper';
import type { ReactNode } from 'react';
import PageTransitionWrapper from '../components/PageTransitionWrapper';

export const metadata = {
  title: 'ApreNova',
  description: 'Learn smarter, not harder. Learn with stories.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" translate="no">
      <head>
        <meta name="google" content="notranslate" />
        <link
          href="https://fonts.googleapis.com/css2?family=Alice&family=Open+Sans:wght@400;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-background text-foreground font-sans">
        <SessionWrapper>
          <PageTransitionWrapper>{children}</PageTransitionWrapper>
        </SessionWrapper>
      </body>
    </html>
  );
}
